package com.amirali.timetravel

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Base64
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var out: OutputStream? = null
    private val picked = HashMap<String, Uri>()
    private var pickKind = ""
    private var counter = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowContentAccess = true
        }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val path = request.url.path ?: ""
                if (path.startsWith("/picked/")) {
                    val u = picked[path.removePrefix("/picked/")] ?: return null
                    return try {
                        WebResourceResponse(
                            contentResolver.getType(u) ?: "application/octet-stream", null, 200, "OK",
                            mapOf("Access-Control-Allow-Origin" to "*"),
                            contentResolver.openInputStream(u)
                        )
                    } catch (e: Exception) { null }
                }
                return loader.shouldInterceptRequest(request.url)
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(v: WebView, url: String, msg: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(msg)
                    .setPositiveButton("تأیید") { _, _ -> r.confirm() }
                    .setNegativeButton("انصراف") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsAlert(v: WebView, url: String, msg: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(msg)
                    .setPositiveButton("باشه") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.confirm() }.show()
                return true
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != 2 || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
        } else {
            data.data?.let { uris.add(it) }
        }
        val arr = JSONArray()
        for (u in uris) {
            val id = (++counter).toString()
            picked[id] = u
            var name = ""
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ix >= 0) name = c.getString(ix) ?: ""
                }
            }
            val o = JSONObject()
            o.put("url", "https://appassets.androidplatform.net/picked/$id")
            o.put("type", contentResolver.getType(u) ?: "")
            o.put("name", name)
            arr.put(o)
        }
        web.evaluateJavascript("window.onNativePick(" + JSONObject.quote(pickKind) + "," + arr.toString() + ")", null)
    }

    inner class Bridge {
        @JavascriptInterface fun pick(kind: String) {
            runOnUiThread {
                pickKind = kind
                val i = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = when (kind) { "image" -> "image/*"; "video" -> "video/*"; "audio" -> "audio/*"; else -> "*/*" }
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, kind == "image" || kind == "video")
                }
                try { startActivityForResult(i, 2) } catch (e: Exception) { }
            }
        }

        private fun open(name: String, mime: String): OutputStream {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TIME TRAVEL")
                }
                val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
                return contentResolver.openOutputStream(u)!!
            }
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "TIME TRAVEL")
            dir.mkdirs()
            return FileOutputStream(File(dir, name))
        }
        @JavascriptInterface fun begin(name: String, mime: String): Boolean =
            try { out = open(name, mime); true } catch (e: Exception) { false }
        @JavascriptInterface fun chunk(b64: String) { out?.write(Base64.decode(b64, Base64.DEFAULT)) }
        @JavascriptInterface fun end() { out?.close(); out = null }
    }
}
