TIME TRAVEL - Android project
Option A (Android Studio): open this folder > Build > Build APK(s).
Option B (GitHub, no PC tools): upload all files to a new GitHub repo > Actions tab > "Build APK" > download artifact TIME-TRAVEL-apk (app-debug.apk).
